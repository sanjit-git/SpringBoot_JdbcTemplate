package com.jdbc.pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTwoDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTwoDatabaseApplication.class, args);
	}

}
