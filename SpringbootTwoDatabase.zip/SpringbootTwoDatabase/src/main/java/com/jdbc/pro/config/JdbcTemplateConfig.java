package com.jdbc.pro.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class JdbcTemplateConfig {
	
	@Value("${spring.datasource.mysql.url}")
    private String mysqlUrl;

    @Value("${spring.datasource.mysql.username}")
    private String mysqlUsername;

    @Value("${spring.datasource.mysql.password}")
    private String mysqlPassword;

    @Value("${spring.datasource.mysql.driver-class-name}")
    private String mysqlDriverClassName;
    
    @Bean(name = "mysqlDataSource")
    public DataSource mysqlDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(mysqlUrl);
        dataSource.setUsername(mysqlUsername);
        dataSource.setPassword(mysqlPassword);
        dataSource.setDriverClassName(mysqlDriverClassName);
        return dataSource;
    }

    @Value("${spring.datasource.h2.url}")
    private String h2Url;

    @Value("${spring.datasource.h2.username}")
    private String h2Username;

    @Value("${spring.datasource.h2.password}")
    private String h2Password;

    @Value("${spring.datasource.h2.driver-class-name}")
    private String h2DriverClassName;

    @Bean(name = "h2DataSource")
    public DataSource h2DataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(h2Url);
        dataSource.setUsername(h2Username);
        dataSource.setPassword(h2Password);
        dataSource.setDriverClassName(h2DriverClassName);
        return dataSource;
    }

//    @Bean(name = "mysqlJdbcTemplate")
//    public JdbcTemplate mysqlJdbcTemplate(@Qualifier("mysqlDataSource") DataSource mysqlDataSource) {
//        return new JdbcTemplate(mysqlDataSource);
//    }
//
//    @Bean(name = "h2JdbcTemplate")
//    public JdbcTemplate h2JdbcTemplate(@Qualifier("h2DataSource") DataSource h2DataSource) {
//        return new JdbcTemplate(h2DataSource);
//    }
    
    
  //********************************************************
	
//	@Bean(name = "mysqlDataSource")
//    public DataSource mysqlDataSource() {
//        return DataSourceBuilder.create()
//                .url("jdbc:mysql://localhost:3306/Test")
//                .username("root")
//                .password("sanjit")
//                .driverClassName("com.mysql.cj.jdbc.Driver")
//                .build();
//    }
//	
//	@Bean(name = "h2DataSource")
//    public DataSource h2DataSource() {
//        return DataSourceBuilder.create()
//                .url("jdbc:postgresql://localhost:5432/Testdb")
//                .username("postgres")
//                .password("sanjit")
//                .driverClassName("org.postgresql.Driver")
//                .build();
//    }
	
//	@Bean(name = "mysqlDataSource")
//	@ConfigurationProperties(prefix = "spring.datasource.mysql")
//	public DataSource mysqlDataSource() {
//		return DataSourceBuilder.create().build();
//	}
//
//	@Bean(name = "h2DataSource")
//	@ConfigurationProperties(prefix = "spring.datasource.h2")
//	public DataSource h2DataSource() {
//		return DataSourceBuilder.create().build();
//	}

	@Bean(name = "mysqlJdbcTemplate")
	public JdbcTemplate mysqlJdbcTemplate(@Qualifier("mysqlDataSource") DataSource mysqlDataSource) {
		return new JdbcTemplate(mysqlDataSource);
	}

    @Bean(name = "h2JdbcTemplate")
    public JdbcTemplate h2JdbcTemplate(@Qualifier("h2DataSource") DataSource h2DataSource) {
        return new JdbcTemplate(h2DataSource);
    }


}
