package com.jdbc.pro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jdbc.pro.model.Employee;
import com.jdbc.pro.service.DataService;

@RestController
@RequestMapping("/api/data")
public class DataController {
    private final DataService dataService;

    @Autowired
    public DataController(DataService dataService) {
        this.dataService = dataService;
    }

    @GetMapping("/matchingData")
    public ResponseEntity<List<Employee>> getMatchingData() {
        List<Employee> matchingData = dataService.getMatchingData();
        return ResponseEntity.ok(matchingData);
    }
}

