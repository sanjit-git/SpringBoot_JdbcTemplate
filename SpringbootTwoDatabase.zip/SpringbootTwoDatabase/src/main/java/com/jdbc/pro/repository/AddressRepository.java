package com.jdbc.pro.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jdbc.pro.model.Address;

@Repository
public class AddressRepository {

    private final JdbcTemplate h2JdbcTemplate;

    @Autowired
    public AddressRepository(@Qualifier("h2JdbcTemplate") JdbcTemplate h2JdbcTemplate) {
        this.h2JdbcTemplate = h2JdbcTemplate;
    }

    public List<Address> findAll() {
        return h2JdbcTemplate.query("SELECT id, city FROM address", (rs, rowNum) -> {
            Address address = new Address();
            address.setId(rs.getInt("id"));
            address.setCity(rs.getString("city"));
            return address;
        });
    }
    
}