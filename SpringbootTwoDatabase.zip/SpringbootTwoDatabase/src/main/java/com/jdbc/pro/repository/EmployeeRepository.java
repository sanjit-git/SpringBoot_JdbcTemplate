package com.jdbc.pro.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jdbc.pro.model.Employee;

@Repository
public class EmployeeRepository {

    private final JdbcTemplate mysqlJdbcTemplate;

    @Autowired
    public EmployeeRepository(@Qualifier("mysqlJdbcTemplate") JdbcTemplate mysqlJdbcTemplate) {
        this.mysqlJdbcTemplate = mysqlJdbcTemplate;
    }

    public List<Employee> findAll() {
        return mysqlJdbcTemplate.query("SELECT id, name FROM employee", (rs, rowNum) -> {
        	Employee emp = new Employee();
        	emp.setId(rs.getInt("id"));
        	emp.setName(rs.getString("name"));
            return emp;
        });
    }
}
