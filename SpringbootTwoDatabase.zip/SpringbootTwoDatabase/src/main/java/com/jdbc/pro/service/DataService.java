package com.jdbc.pro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jdbc.pro.model.Address;
import com.jdbc.pro.model.Employee;
import com.jdbc.pro.repository.AddressRepository;
import com.jdbc.pro.repository.EmployeeRepository;

@Service
public class DataService {

	private final EmployeeRepository empRepository;
    private final AddressRepository addressRepository;

    @Autowired
    public DataService(EmployeeRepository empRepository, AddressRepository addressRepository) {
        this.empRepository = empRepository;
        this.addressRepository = addressRepository;
    }

    public List<Employee> getMatchingData() {
        List<Employee> emp = empRepository.findAll();
        List<Address> addresses = addressRepository.findAll();
        List<Employee> matchingData = new ArrayList<>();
        for (Employee empdata : emp) {
            for (Address address : addresses) {
                if (empdata.getId() == (address.getId())) {
                	empdata.setPlace(address.getCity());
                    matchingData.add(empdata);
                }
            }
        }
        return matchingData;
    }
}
